
/*Realizar un programa en C, donde se pida el ingreso del radio y luego se presente
un men� de 3 opciones de c�lculo: (a)-C�lculo de la longitud de la circunferencia,
(b)-C�lculo del �rea del c�rculo y (c)-C�lculo del volumen de la esfera, se pida el
ingreso de la opci�n elegida, se realice el c�lculo correspondiente y se muestre
el resultado. Utilizar la if-else-if.*/

#include <stdio.h>
#include <math.h>

int main(void) {
	char op;
	float radio;
	float circunsferencia, area, volumen;
	float PI=3.14159;
	
	printf ("a)-C�lculo de la longitud de la circunferencia\n");
	printf ("b)-C�lculo del �rea del c�rculo\n");
	printf ("c)-C�lculo del volumen de la esfera\n\n");
	printf ("Elija una opci�n: ");
	scanf("%c", &op);

	printf ("Ingrese el radio: ");
	scanf ("%f", &radio);
	
	if ((op=='a')||(op=='A')){
		//circunsferencia= PI*2*radio;
		printf ("Circunsferencia= %f\n", circunsferencia);
		}
	else if ((op=='b')||(op=='B')){
		//area=PI*radio*radio;
		printf ("Area= %f\n", area);
		}
	else if ((op=='c')||(op=='C')){
		volumen=4.0/3.0 * PI * pow(radio, 3);
		//printf ("Volumen= %f\n", volumen);
		}
	else 
		printf ("Opci�n no v�lida");

	
	return 0;
}
