#include<stdio.h>
#include<math.h>
int main(){
	int x=0;
	float y=0;
	
	printf("Ingrese el valor de (X) para calcular su derivada\n");
	scanf("%d",&x);
	y=sin(2*x);
	printf("%f",y);
	
}
